# Test1
echo "# Test1" >> Code
git init
git add Code
git commit -m "first commit"
git remote add origin https://github.com/favreju/Test1.git
git push -u origin master
